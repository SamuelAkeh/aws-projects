vol_id=vol-059bb09b4186ea3ae

aws ec2 delete-volume --volume-id $vol_id
