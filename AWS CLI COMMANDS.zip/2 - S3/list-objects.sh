bucket_name="codebase101-demo"

aws s3api list-objects-v2 --bucket $bucket_name
