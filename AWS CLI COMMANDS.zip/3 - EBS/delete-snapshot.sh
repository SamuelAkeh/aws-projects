aws ec2 delete-snapshot --snapshot-id snap-0cf617737e0487b9e
