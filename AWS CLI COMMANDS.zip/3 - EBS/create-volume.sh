aws ec2 create-volume \
    --volume-type gp3 \
    --size 80 \
    --region eu-west-2 \
    --availability-zone eu-west-2a
