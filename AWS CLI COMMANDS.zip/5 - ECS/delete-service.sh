aws ecs delete-service \
  --cluster fargate-cluster \
  --service fargate-service \
  --force