aws ecs delete-cluster --cluster MyCluster
