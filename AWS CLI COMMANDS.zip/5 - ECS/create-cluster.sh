aws ecs create-cluster --cluster-name MyCluster
