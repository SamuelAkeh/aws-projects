bucket_name="codebase101-demo"

aws s3 rm s3://$bucket_name --recursive
