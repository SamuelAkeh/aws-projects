aws efs delete-file-system \
    --file-system-id fs-c7a0456e
