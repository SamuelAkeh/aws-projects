aws s3control create-access-point \
    --account-id 123456789012 \
    --bucket codebase-demo \
    --name demo-ap
