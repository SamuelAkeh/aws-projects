aws s3api list-buckets --query "Buckets[].Name"
