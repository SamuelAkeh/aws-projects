aws s3control delete-access-point \
    --account-id 123456789012 \
    --name demo-ap
