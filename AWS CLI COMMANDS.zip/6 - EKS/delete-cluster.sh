
aws eks delete-cluster --name my-eks-cluster
