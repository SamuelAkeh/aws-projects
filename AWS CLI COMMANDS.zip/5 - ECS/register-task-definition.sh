aws ecs register-task-definition --cli-input-json file://httpd-task-def.json
